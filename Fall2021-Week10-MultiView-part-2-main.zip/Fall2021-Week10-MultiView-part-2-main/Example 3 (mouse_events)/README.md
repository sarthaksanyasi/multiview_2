# Interaction between two plots 
## bivariant data representation

The manipulation of a visualization can start with users' exploring data and finding the relations using mouse over effect.
In this example the mouseover effect is implemented using d3js on("mouseenter") and on("mouseleave") functions.